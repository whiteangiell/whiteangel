<?php
return [
    'home' => 'الرئيسية',
    'about_us' => 'معلومات عنا',
    'who_we_are' => 'من نحن',
    'who_we_are_desc' => 'نحن فريق من المحترفين المكرسين...',
    'what_we_do' => 'ماذا نفعل',
    'what_we_do_desc' => 'نقدم خدمات متنوعة...',
    'why_choose_us' => 'لماذا تختارنا',
    'why_choose_us_desc' => 'لدينا سنوات من الخبرة...',
    'testimonial_quote' => 'أفضل خدمة على الإطلاق!',
    'testimonial_author_name' => 'جون دو',
    'testimonial_author_role' => 'الرئيس التنفيذي للشركة',
    'our_clients' => 'عملاؤنا',
    'total_categories' => 'إجمالي الفئات',
    'in_country' => 'في البلاد',
    'happy_customer' => 'عميل سعيد',
    'our_team' => 'فريقنا',
    'meet_our_team' => 'تعرف على فريقنا',
    'team_member_1' => 'أليس سميث',
    'team_member_1_role' => 'مطورة ويب',
    'team_member_2' => 'بوب جونسون',
    'team_member_2_role' => 'مصمم جرافيك',
    'team_member_3' => 'تشارلي براون',
    'team_member_3_role' => 'مدير المشروع',
    'team_member_4' => 'ديزي ميلر',
    'team_member_4_role' => 'أخصائية تسويق',
    'partner' => 'شريك',
    'happy_clients' => 'عملاء سعداء',
    'title' => 'وایت انجل',
    'about' => 'معلومات عنا',
    'shop' => 'متجر',
    'contact' => 'اتصل',
    'language' => 'اللغة',
    'hero_subtitle' => 'مجموعة الصيف',
    'hero_title' => 'مجموعات الخريف - الشتاء 2030',
    'hero_description' => 'علامة متخصصة تقدم مستلزمات فاخرة. مصنوعة بأخلاق عالية مع التزام لا يتزعزع بالجودة الاستثنائية.',
    'shop_now' => 'تسوق الآن',
    'collection_title' => 'مجموعات الملابس 2030',
    'accessories' => 'إكسسوارات',
    'shoes_spring' => 'أحذية ربيع 2030',
    'best_sellers' => 'أفضل المبيعات',
    'new_arrivals' => 'وصول جديدة',
    'hot_sales' => 'مبيعات ساخنة',
    'new' => 'جديد',
    'sale' => 'تخفيض',
    // 'instagram' => 'انستاغرام',
    'instagram2' => 'عربي وسف',
  // lastet news 
  'latest_news' => 'أحدث الأخبار',
  'fashion_new_trends' => 'اتجاهات الموضة الجديدة',
//   footer
'newsletter' => 'النشرة الإخبارية',
  'collection' => 'المجموعة',
  'newsletter2' => 'كن أول من يعرف عن المنتجات الجديدة، والكتب، والمبيعات والعروض الترويجية!',
  'information' => 'المعلومات',
'contact_description' => 'كما قد تتوقع من شركة بدأت كمقاول للتصميمات الداخلية الراقية، فإننا نولي اهتمامًا صارمًا.
',


    // Social Media Platforms
    'facebook' => 'فيسبوك',
    'instagram' => 'انستاغرام',
    'snapchat' => 'سناب شات',
    'tiktok' => 'تيك توك',
    'whatsapp' => 'واتس آب',
    'shopping' => 'التسوق',
    'social' => 'سوشیال',
    'custumer1' => 'يعتبر العميل هو محور نموذج أعمالنا الفريد، والذي يشمل التصميم.',

    'location1' => 'عنوان برج عدالة طابق 3 غرفة32',
    'number1' => 'abdullahsmajeed9@gmail.com',
    'location2' => 'رانیە',
    'number2' => '9647504292464',
    'name' => 'الاسم',
    'email' => 'برید الاکتروني',
    'message' => 'رسالة',
    
    'send_message' => 'ارسال رسالة',











    'products' => [
        [
            'name' => 'سترة راكبي الدراجات Piqué',
            'price' => '$67.24',
        ],
        [
            'name' => 'حقيبة صدر متعددة الجيوب',
            'price' => '$43.48',
        ],
        [
            'name' => 'قبعة بنمط مائل',
            'price' => '$60.9',
        ],
        [
            'name' => 'حقيبة ظهر جلدية',
            'price' => '$31.37',
        ],
        [
            'name' => 'أحذية الكاحل',
            'price' => '$98.49',
        ],
        [
            'name' => 'تي شيرت بجيب متباين',
            'price' => '$49.66',
        ],
        [
            'name' => 'وشاح أساسي متدفق',
            'price' => '$26.28',
        ],
    ],
];
?>
