<?php
return [
    'home' => 'سەرەتا',
    'about_us' => 'دەربارەی ئیمە',
    'who_we_are' => 'ئێمە کێین؟',
    'who_we_are_desc' => 'ئیمە تیمێکی تایبەتی خێرایی...',
    'what_we_do' => 'ئیمە چەند ئەنجام دەدەن',
    'what_we_do_desc' => 'خزمەتگوزاریەکان تایبەتی پێشکەش دەکەین...',
    'why_choose_us' => 'بۆچی ئێمە هەڵبژێرە',
    'why_choose_us_desc' => 'ئیمە ساڵانە زانایەتی هەیە...',
    'testimonial_quote' => 'باشترین خزمەتگوزاری!',
    'testimonial_author_name' => 'جون دو',
    'testimonial_author_role' => 'بەڕێوەبەر',
    'our_clients' => 'موشتەریەکانمان',
    'total_categories' => 'کۆی پەڕگەکان',
    'in_country' => 'لە وڵات',
    'happy_customer' => 'موشتەری خۆش',
    'our_team' => 'تیمەکانمان',
    'meet_our_team' => 'بە هەناسەمان بنەماو',
    'team_member_1' => 'أليس سميث',
    'team_member_1_role' => 'مطور ويب',
    'team_member_2' => 'بوب جونسون',
    'team_member_2_role' => 'مصمم جرافيك',
    'team_member_3' => 'تشارلي براون',
    'team_member_3_role' => 'مدير المشروع',
    'team_member_4' => 'ديزي ميلر',
    'team_member_4_role' => 'أخصائية تسويق',
    'partner' => 'شریک',
    'happy_clients' => 'عملاء سعداء',
    'title' => 'وایت ئەنجێڵ',
    'about' => 'دەربارە',
    'shop' => 'دوکان',
    'contact' => 'پەیوەندی',
    'language' => 'زمان',
    'hero_subtitle' => 'کۆلێکشنی هاوین',
    'hero_title' => 'کۆلێکشنەکانی پایز - زستان 2030',
    'hero_description' => 'براندێکی تایبەتی شتە .... .',
    'shop_now' => 'ئێستا کڕین بکە',
    'collection_title' => 'کۆلێکشنەکانی جل و بەرگ 2030',
    'accessories' => 'پەیوەندەکانی خواردنەوە',
    'shoes_spring' => 'پێڵاوی بەھار 2030',
    'best_sellers' => 'بەرهەمە تایبەتی',
    'new_arrivals' => 'بەرهەمی نوێ',
    'hot_sales' => 'فروشی گەرم',
    'new' => 'نوێ',
    'sale' => 'فروشی تایبەتی',
    // 'instagram' => 'ئینستاگرام',
    'instagram2' => 'وەسفی کوردی',
      // lastet news 
      'latest_news' => 'نوێترین هەواڵ',
      'fashion_new_trends' => 'ڕەوتە نوێیەکانی مۆدە',
    //   footer
    'newsletter' => 'هەواڵنامە',
      'collection' => 'گروپەکان',
      'newsletter2' => 'یەکەم کەس بە کە بزانێت دەربارەی تازەهاتووان، کتێبی سەیرکردن، فرۆشتن و پرۆمۆ!',
      'information' => 'زانیاری',

'contact_description' => 'وەک چاوەڕوان دەکرێت لە کۆمپانیایەک کە وەک بەڵێندەرێکی ناوەوەی ئاست بەرز دەستی پێکردووە
 گرنگیدانی توند.',
    // Social Media Platforms
    'facebook' => 'فەیسبوک',
    'instagram' => 'ئینستاگرام',
    'snapchat' => 'سناپچات',
    'tiktok' => 'تیکتۆک',
    'whatsapp' => 'وەتس ئاپ',
    'shopping' => 'بازاڕکردن',
    'social' => 'سۆشیال',
    'custumer1' => 'کڕیار لە دڵی مۆدێلی بازرگانی ناوازەماندایە، کە دیزاین لەخۆدەگرێت.',

    
    'location1' => 'ناونیشان: تاوەری عەدالت، نهۆمی سێیەم، ژووری ٣٢',
    'number1' => 'abdullahsmajeed9@gmail.com',
    'location2' => 'ڕانیە',
    'number2' => '9647504292464',    
    'send_message' => 'نامەکە بنێرە',
    'name' => 'ناو',
    'email' => 'ئیمەیڵ',
    'message' => 'پەیام',
    

    
    'products' => [
        [
            'name' => 'کتەی بایکر Piqué',
            'price' => '$67.24',
        ],
        [
            'name' => 'پەشتی کەشی زنجیرە',
            'price' => '$43.48',
        ],
        [
            'name' => 'کاپی دیاریکراو',
            'price' => '$60.9',
        ],
        [
            'name' => 'پەشتی پارچەی فۆبەر',
            'price' => '$31.37',
        ],
        [
            'name' => 'پیشانگا',
            'price' => '$98.49',
        ],
        [
            'name' => 'تی شرتی بەرز',
            'price' => '$49.66',
        ],
        [
            'name' => 'دسکا بیست',
            'price' => '$26.28',
        ],
    ],
];
?>
