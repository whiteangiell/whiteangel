<?php
return [
    // Header Section
    'title' => 'White Angel',
    'home' => 'Home',
    'about' => 'About Us',
    'shop' => 'Shop',
    'contact' => 'Contacts',
    'language' => 'Language',

    // About Us Section
    'who_we_are' => 'Who We Are',
    'who_we_are_desc' => 'We are a team of dedicated professionals...',
    'what_we_do' => 'What We Do',
    'what_we_do_desc' => 'We provide various services...',
    'why_choose_us' => 'Why Choose Us',
    'why_choose_us_desc' => 'We have years of experience...',

    // Testimonials
    'testimonial_quote' => 'The best service ever!',
    'testimonial_author_name' => 'John Doe',
    'testimonial_author_role' => 'CEO of Company',

    // Clients and Statistics
    'our_clients' => 'Our Clients',
    'total_categories' => 'Total Categories',
    'in_country' => 'In Country',
    'happy_customer' => 'Happy Customer',

    // Team Section
    'our_team' => 'Our Team',
    'meet_our_team' => 'Meet Our Team',
    'team_member_1' => 'Alice Smith',
    'team_member_1_role' => 'Web Developer',
    'team_member_2' => 'Bob Johnson',
    'team_member_2_role' => 'Graphic Designer',
    'team_member_3' => 'Charlie Brown',
    'team_member_3_role' => 'Project Manager',
    'team_member_4' => 'Daisy Miller',
    'team_member_4_role' => 'Marketing Specialist',

    // Miscellaneous
    'partner' => 'Partner',
    'happy_clients' => 'Happy Clients',

    // Homepage Specific
    'hero_subtitle' => 'Summer Collection',
    'hero_title' => 'Fall - Winter Collections 2030',
    'hero_description' => 'A specialist label creating luxury essentials. Ethically crafted with an unwavering commitment to exceptional quality.',
    'shop_now' => 'Shop now',
    'collection_title' => 'Clothing Collections 2030',
    'accessories' => 'Accessories',
    'shoes_spring' => 'Shoes Spring 2030',
    // 'instagram' => 'Instagram',
    'instagram2' => 'english text',
    

    // lastet news 
    'latest_news' => 'Latet News',
    'fashion_new_trends' => 'Fashion New Trends',
   
    
    // footer
    'newsletter' => 'NewsLetter',
    'collection' => 'Collection',
    'newsletter2' => 'Be the first to know about new arrivals, look books, sales & promos!',
    'information' => 'Information',
    'contact_description' => 'As you might expect of a company that began as a high-end interiors contractor, we pay
                                strict attention.',

        // Social Media Platforms
        'social' => 'Social',
        'facebook' => 'Facebook',
        'instagram' => 'Instagram',
        'snapchat' => 'Snapchat',
        'tiktok' => 'Tiktok',
        'whatsapp' => 'WhatsApp',
        'shopping' => 'Shopping',
        'custumer1' => 'The customer is at the heart of our unique business model, which includes design.',
        'location1' => 'Adala Tower Address, 3rd Floor, Room 32',
        'number1' => 'abdullahsmajeed9@gmail.com',
        'location2' => 'Rania',
        'number2' => '9647504292464',
    'name' => 'Name',
    'email' => 'Email',
    'message' => 'Message',
        
        'send_message' => 'Send Messeage',
        

    





























        'best_sellers' => 'Best Sellers',
        'new_arrivals' => 'New Arrivals',
        'hot_sales' => 'Hot Sales',
        'new' => 'New',
        'sale' => 'Sale',
        'products' => [
            [
                'name' => 'Piqué Biker Jacket',
                'price' => '$67.24',
            ],
            [
                'name' => 'Multi-pocket Chest Bag',
                'price' => '$43.48',
            ],
            [
                'name' => 'Diagonal Textured Cap',
                'price' => '$60.9',
            ],
            [
                'name' => 'Lether Backpack',
                'price' => '$31.37',
            ],
            [
                'name' => 'Ankle Boots',
                'price' => '$98.49',
            ],
            [
                'name' => 'T-shirt Contrast Pocket',
                'price' => '$49.66',
            ],
            [
                'name' => 'Basic Flowing Scarf',
                'price' => '$26.28',
            ],
        ],
    ];
    ?>