<?php
// session_start();

// Set default language as English
// if (!isset($_SESSION['lang'])) {
//     $_SESSION['lang'] = 'en';
// }

// Handle language switch
// if (isset($_GET['lang'])) {
//     $_SESSION['lang'] = $_GET['lang'];
// }

// Include the selected language file
// include("languages/" . $_SESSION['lang'] . ".php");
?>

<?php include('./header.php'); ?>

    <!-- Page Preloder -->
    <!-- <div id="preloder">
        <div class="loader"></div>
    </div> -->
    <!-- Breadcrumb Section Begin -->
    <section class="breadcrumb-option">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb__text">
                        <h4><?php echo $lang['about']; ?></h4>
                        <div class="breadcrumb__links">
                            <a href="./index.html"><?php echo $lang['home']; ?></a>
                            <span><?php echo $lang['about']; ?></span>                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!-- About Section Begin -->
    <section class="about spad" style="<?php if ($lang2 == 'ar' || $lang2 == 'ku')  { echo 'text-align:right;'; } ?>">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="about__pic">
                        <img src="img/about/about-us.jpg" alt="">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="about__item">
                        <h4><?php echo $lang['who_we_are']; ?></h4>
                        <p><?php echo $lang['who_we_are_desc']; ?></p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="about__item">
                        <h4><?php echo $lang['what_we_do']; ?></h4>
                        <p><?php echo $lang['what_we_do_desc']; ?></p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="about__item">
                        <h4><?php echo $lang['why_choose_us']; ?></h4>
                        <p><?php echo $lang['why_choose_us_desc']; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- About Section End -->

    <!-- Testimonial Section Begin -->
    <section class="testimonial">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 p-0">
                    <div class="testimonial__text">
                        <span class="icon_quotations"></span>
                        <p><?php echo $lang['testimonial_quote']; ?></p>
                        <div class="testimonial__author">
                            <div class="testimonial__author__pic">
                                <img src="img/about/testimonial-author.jpg" alt="">
                            </div>
                            <div class="testimonial__author__text">
                                <h5><?php echo $lang['testimonial_author_name']; ?></h5>
                                <p><?php echo $lang['testimonial_author_role']; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 p-0">
                    <div class="testimonial__pic set-bg" data-setbg="img/about/testimonial-pic.jpg"></div>
                </div>
            </div>
        </div>
    </section>
    <!-- Testimonial Section End -->

    <!-- Counter Section Begin -->
    <section class="counter spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="counter__item">
                        <div class="counter__item__number">
                            <h2 class="cn_num">102</h2>
                        </div>
                        <span><?php echo $lang['our_clients']; ?></span>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="counter__item">
                        <div class="counter__item__number">
                            <h2 class="cn_num">30</h2>
                        </div>
                        <span><?php echo $lang['total_categories']; ?></span>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="counter__item">
                        <div class="counter__item__number">
                            <h2 class="cn_num">102</h2>
                        </div>
                        <span><?php echo $lang['in_country']; ?></span>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="counter__item">
                        <div class="counter__item__number">
                            <h2 class="cn_num">98</h2>
                            <strong>%</strong>
                        </div>
                        <span><?php echo $lang['happy_customer']; ?></span>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Counter Section End -->

    <!-- Team Section Begin -->
    <section class="team spad" style="<?php if ($lang2 == 'ar' || $lang2 == 'ku')  { echo 'text-align:right;'; } ?>">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <span><?php echo $lang['our_team']; ?></span>
                        <h2><?php echo $lang['meet_our_team']; ?></h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="team__item">
                        <img src="img/about/team-1.jpg" alt="">
                        <h4><?php echo $lang['team_member_1']; ?></h4>
                        <span><?php echo $lang['team_member_1_role']; ?></span>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="team__item">
                        <img src="img/about/team-2.jpg" alt="">
                        <h4><?php echo $lang['team_member_2']; ?></h4>
                        <span><?php echo $lang['team_member_2_role']; ?></span>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="team__item">
                        <img src="img/about/team-3.jpg" alt="">
                        <h4><?php echo $lang['team_member_3']; ?></h4>
                        <span><?php echo $lang['team_member_3_role']; ?></span>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="team__item">
                        <img src="img/about/team-4.jpg" alt="">
                        <h4><?php echo $lang['team_member_4']; ?></h4>
                        <span><?php echo $lang['team_member_4_role']; ?></span>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Team Section End -->

    <!-- Client Section Begin -->
    <section class="clients spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <span><?php echo $lang['partner']; ?></span>
                        <h2><?php echo $lang['happy_clients']; ?></h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3 col-md-4 col-sm-4 col-6">
                    <a href="#" class="client__item"><img src="img/clients/client-1.png" alt=""></a>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-4 col-6">
                    <a href="#" class="client__item"><img src="img/clients/client-2.png" alt=""></a>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-4 col-6">
                    <a href="#" class="client__item"><img src="img/clients/client-3.png" alt=""></a>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-4 col-6">
                    <a href="#" class="client__item"><img src="img/clients/client-4.png" alt=""></a>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-4 col-6">
                    <a href="#" class="client__item"><img src="img/clients/client-5.png" alt=""></a>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-4 col-6">
                    <a href="#" class="client__item"><img src="img/clients/client-6.png" alt=""></a>
                </div>
            </div>
        </div>
    </section>
    <!-- Client Section End -->

    <?php include('./footer.php'); ?>
