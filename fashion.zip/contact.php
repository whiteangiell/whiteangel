<?php include('./header.php'); ?>

    <!-- Map Begin -->
    <div class="map">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d8080.796468278395!2d43.97246478587038!3d36.18111083386182!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40072342c387aebf%3A0x1626fe053a1cb0e4!2z2KjYsdisINi52K_Yp9mE2Kk!5e1!3m2!1sen!2siq!4v1730314502486!5m2!1sen!2siq" height="500" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>

    </div>
    <!-- Map End -->

    <!-- Contact Section Begin -->
    <section class="contact spad" style="<?php if ($lang2 == 'ar' || $lang2 == 'ku')  { echo 'text-align:right;'; } ?>">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6">
                    <div class="contact__text">
                        <div class="section-title">
                            <span><?php echo $lang['information']; ?></span>
                            <h2><?php echo $lang['contact']; ?></h2>
                            <p><?php echo $lang['contact_description']; ?>
                            </p>
                        </div>
                        <ul>
                            <li>
                                <h4><?php echo $lang['location1']; ?></h4>
                                <p><br /><a href="tel:+<?php echo $lang['number2']; ?>"><?php echo $lang['number2']; ?></a></p>

                                <p> <br /><a href="mailto:<?php echo $lang['number1']; ?>"><?php echo $lang['number1']; ?></a></p>
                                
                            </li>
                            <li>
                                <!-- <h4><?php //echo $lang['location2']; ?></h4> -->
                                <!-- <p><br /><?php //echo $lang['number2']; ?></p> -->
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="contact__form">
                        <form action="#">
                            <div class="row">
                                <div class="col-lg-6">
                                    <input type="text" placeholder="<?php echo $lang['name']; ?>">
                                </div>
                                <div class="col-lg-6">
                                    <input type="text" placeholder="<?php echo $lang['email']; ?>">
                                </div>
                                <div class="col-lg-12">
                                    <textarea placeholder="<?php echo $lang['message']; ?>"></textarea>
                                    <button type="submit" class="site-btn"><?php echo $lang['send_message']; ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Contact Section End -->

    <?php include('./footer.php'); ?>