    <!-- Footer Section Begin -->
  <!-- Footer Section Begin -->
  <footer class="footer" style="<?php if ($lang2 == 'ar' || $lang2 == 'ku')  { echo 'text-align:right;'; } ?>">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="footer__about">
                    <div class="footer__logo">
                        <a href="#">
                        <!-- <?php //echo $lang['title'] ?> -->
                            <!-- <img src="img/footer-logo.png" alt="">-->
                            <img src="img/logo/fashion.jpg" alt="" style="width:100px;">
                            </a> 
                    </div>
                    <p><?php echo $lang['custumer1']; ?></p>
                    <a href="#"><img src="img/payment.png" alt=""></a>
                </div>
            </div>
            <div class="col-lg-2 offset-lg-1 col-md-3 col-sm-6">
                <div class="footer__widget">
                    <h6><?php echo $lang['shopping'] ?></h6>
                    <ul>
                        <li><a href="./index.html"><?php echo $lang['home'] ?></a></li>
                        <li><a href="./index.html#Collection"><?php echo $lang['collection'] ?></a></li>
                        <li><a href="./shop.html"><?php echo $lang['shop'] ?></a></li>
                        <li><a href="./about.html"><?php echo $lang['about'] ?></a></li>
                        <li><a href="./contact.html"><?php echo $lang['contact'] ?></a></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-3 col-sm-6">
                <div class="footer__widget">
                    <h6><?php echo $lang['social'] ?></h6>
                    <ul>
                        <li><a href="#"><?php echo $lang['facebook'] ?></a></li>
                        <li><a href="#"><?php echo $lang['instagram'] ?></a></li>
                        <li><a href="#"><?php echo $lang['snapchat'] ?></a></li>
                        <li><a href="#"><?php echo $lang['tiktok'] ?></a></li>
                        <li><a href="#"><?php echo $lang['whatsapp'] ?></a></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3 offset-lg-1 col-md-6 col-sm-6">
                <div class="footer__widget">
                    <h6><?php echo $lang['newsletter']; ?></h6>
                    <div class="footer__newslatter">
                        <p><?php echo $lang['newsletter2']; ?></p>
                        <form action="#">
                            <input type="text" placeholder="Your email">
                            <button type="submit"><span class="icon_mail_alt"></span></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="footer__copyright__text">
                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    <p>Copyright ©
                        <script>
                            document.write(new Date().getFullYear());
                        </script>
                        All rights reserved | <a href="" target="_blank">Fashion</a>
                    </p>
                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Footer Section End -->

<!-- Search Begin -->
<div class="search-model">
    <div class="h-100 d-flex align-items-center justify-content-center">
        <div class="search-close-switch">+</div>
        <form class="search-model-form">
            <input type="text" id="search-input" placeholder="Search here.....">
        </form>
    </div>
</div>
<!-- Search End -->


    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery.nicescroll.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/mixitup.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script> <!-- jQuery -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script> <!-- Popper.js -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script> <!-- Bootstrap JS -->

<script>
    function changeLanguage(lang) {
        window.location.href = "index.php?lang=" + lang;
    }
</script>

</body>

</html>