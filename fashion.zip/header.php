<?php
session_start();

// Set default language to English
if (!isset($_SESSION['lang'])) {
    $_SESSION['lang'] = 'en';
}

// Check for language change
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
}

// Load language file
$lang2 = $_SESSION['lang'];
$lang = include("languages/{$lang2}.php");


// 

// Load the language file based on the user's preference
// if ($translations == 'ar') {
//     include('languages/ar.php');
// } 
// else if ($translations == 'ku'){
//     include('languages/ku.php');
// }
// else {
//     include('languages/en.php');
// }
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo ($lang == 'ar' || $lang == 'ku') ? 'rtl' : 'ltr'; ?>">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="White_Angel">
    <meta name="keywords" content="white_angel, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $translations['title']; ?></title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@300;400;600;700;800;900&display=swap"
    rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
    <!-- <script src="./language.js"></script> -->

     <!-- font -->
     <style>
        @font-face {
            font-family: 'NRT-Reg';
            src: url('./webfont/NRT-Reg.ttf') format('truetype');
            /* You can add other font formats here if needed */
        }

        body {
            font-family: 'NRT-Reg', sans-serif;
        }
       

    </style>
</head>

<body>


    <!-- Offcanvas Menu Begin -->
    <div class="offcanvas-menu-overlay"></div>
    <div class="offcanvas-menu-wrapper">
        <div class="offcanvas__option">
            <!-- <div class="offcanvas__links">
                <a href="#">Sign in</a>
                <a href="#">FAQs</a>
            </div> -->
            <div class="offcanvas__top__hover">
            <span><?php echo $lang['language']; ?> <i class="arrow_carrot-down"></i></span>
                            <ul style="background:black;">
                            <li><a href="?lang=en" class="hover-black">English</a></li>
<li><a href="?lang=ar" class="hover-black">العربية</a></li>
<li><a href="?lang=ku" class="hover-black">کوردی</a></li>

                            </ul>
            </div>
        </div>
        <div class="offcanvas__nav__option">
            <!-- <a href="#" class="search-switch"><img src="img/icon/search.png" alt=""></a>
            <a href="#"><img src="img/icon/heart.png" alt=""></a>
            <a href="#"><img src="img/icon/cart.png" alt=""> <span>0</span></a>
            <div class="price">$0.00</div> -->
        </div>
        <div id="mobile-menu-wrap"></div>
        <!-- <div class="offcanvas__text">
            <p>Free shipping, 30-day return or refund guarantee.</p>
        </div> -->
    </div>
    <!-- Offcanvas Menu End -->

    <!-- Header Section Begin -->
     
    <header class="header">
        <div class="header__top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-7">
                        <!-- <div class="header__top__left">
                            <p>Free shipping, 30-day return or refund guarantee.</p>
                        </div> -->
                    </div>
                    <div class="col-lg-6 col-md-5">
                        <div class="header__top__right">
                            <!-- <div class="header__top__links">
                                <a href="#">Sign in</a>
                                <a href="#">FAQs</a>
                            </div> -->
                            <!-- <div class="header__top__hover">
                                <span>Usd <i class="arrow_carrot-down"></i></span>
                                <ul>
                                    <li>USD</li>
                                    <li>EUR</li>
                                    <li>USD</li>
                                </ul>
                            </div> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-3">
                    <div class="header__logo">
                        <a href="./index.html">
                            <img src="img/logo/fashion3.jpg" alt="" style="width: 100px;">
                            <?php //echo $lang['title']; ?>
                        </a>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <nav class="header__menu mobile-menu">
                        <br>
                        <ul>
                            <li><a href="./index.php"><i class="fa fa-home"></i> <?php echo $lang['home']; ?></a></li>
                            <li><a href="./about.php"><i class="fa fa-info-circle"></i> <?php echo $lang['about']; ?></a></li>
                            <li><a href="./shop.php"><i class="fa fa-shopping-bag"></i> <?php echo $lang['shop']; ?></a></li>
                            <li><a href="./contact.php"><i class="fa fa-envelope"></i> <?php echo $lang['contact']; ?></a></li>
<!-- class="active" -->
                        </ul>
                    </nav>
                </div>
                <div class="col-lg-3 col-md-3">
                    <div class="header__nav__option">
                        <!-- <a href="#" class="search-switch"><img src="img/icon/search.png" alt=""></a>
                        <a href="#"><img src="img/icon/heart.png" alt=""></a>
                        <a href="#"><img src="img/icon/cart.png" alt=""> <span>0</span></a>
                        <div class="price">$0.00</div> -->
                        <div class="header__top__hover">
    <span style="color: black;"><br>
        <?php echo $lang['language']; ?> <i class="arrow_carrot-down"></i>
    </span>
    <ul>
    <li><a href="?lang=en" class="hover-black">English</a></li>
<li><a href="?lang=ar" class="hover-black">العربية</a></li>
<li><a href="?lang=ku" class="hover-black">کوردی</a></li>
<style>
    .hover-black:hover {
    color: coral; /* Change text color to black on hover */
}

</style>
    </ul>
</div>

                    </div>
                </div>
            </div>
          
            <div class="canvas__open" style="margin-top:20px;"><i class="fa fa-bars"></i></div>

        </div>
    </header>
    <!-- Header Section End -->
